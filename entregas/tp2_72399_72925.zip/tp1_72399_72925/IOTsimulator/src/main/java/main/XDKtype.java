package main;

/**
 * Created by rjaf on 31/10/2016.
 */
public enum XDKtype {
    Temperatura , Luminosidade
}
