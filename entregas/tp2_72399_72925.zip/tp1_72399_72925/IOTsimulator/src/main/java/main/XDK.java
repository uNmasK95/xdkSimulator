package main;

/**
 * Created by rjaf on 31/10/2016.
 */
public interface XDK {

    public float getState();
    public XDKtype getType();
}
