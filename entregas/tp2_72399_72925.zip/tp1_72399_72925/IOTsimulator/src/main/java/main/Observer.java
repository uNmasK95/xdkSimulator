package main;

/**
 * Created by rjaf on 29/09/16.
 */
public interface Observer {
    public void update(Subject s);
}
