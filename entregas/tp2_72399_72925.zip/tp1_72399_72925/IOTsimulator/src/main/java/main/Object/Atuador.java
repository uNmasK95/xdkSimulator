package main.Object;
/**
 * Created by rjaf on 27/10/2016.
 */

public interface Atuador {

    public void execute();

}
